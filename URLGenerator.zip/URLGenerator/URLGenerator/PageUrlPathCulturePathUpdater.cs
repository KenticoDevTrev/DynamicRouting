﻿using System;
using System.Collections.Generic;
using System.Linq;

using CMS.Base;
using CMS.DataEngine;
using CMS.DocumentEngine;
using CMS.DocumentEngine.Routing;
using CMS.DocumentEngine.Routing.Internal;

namespace URLGenerator.CMS.DocumentEngine.Routing
{
    /// <summary>
    /// Updates page URL paths for given page in given cultures.
    /// </summary>
    public class PageUrlPathCulturePathsUpdater
    {
        private readonly TreeNode page;


        /// <summary>
        /// Initializes an instance of the <see cref="PageUrlPathCulturePathsUpdater"/> class.
        /// </summary>
        /// <param name="page">The page for which the page URL paths should be updated.</param>
        /// <exception cref="ArgumentNullException"><paramref name="page"/> is <c>null</c>.</exception>
        /// <exception cref="InvalidOperationException"><paramref name="page"/> is not handled by routing feature.</exception>
        public PageUrlPathCulturePathsUpdater(TreeNode page)
        {
            this.page = page ?? throw new ArgumentNullException(nameof(page));
        }


        /// <summary>
        /// Updates page URL paths in all cultures for the given page.
        /// </summary>
        /// <param name="cultureCodes">Culture codes for which URL paths should be updated.</param>
        /// <param name="originalSiteId">The original site ID for page moved across sites.</param>
        /// <param name="newSiteId">The new site ID for page moved across sites.</param>
        public void Update(IEnumerable<string> cultureCodes, int originalSiteId, int newSiteId)
        {
            if (!cultureCodes.Any())
            {
                return;
            }

            var culturePathsToUpdate = GetCulturePathsToUpdate(cultureCodes);

            var cultureSlugs = culturePathsToUpdate
                .Select(path => new CulturePageUrlSlug { CultureCode = path.CultureCode, Slug = new PageUrlPath(path.UrlPath).Slug });
            
            // CUSTOMIZED tfayas
            var updatedCulturePaths = new PageUrlPathBuilderCustom(page, cultureSlugs).Build();

            int lastFormerUrlPathId = PageFormerUrlPathContinuousIntegrationHelper.GetLastFormerUrlPathId();
            var storeFormerUrls = PageRoutingHelper.GetStoreFormerUrls(originalSiteId);

            foreach (var cultureCode in cultureCodes)
            {
                var originalPath = culturePathsToUpdate.First(path => path.CultureCode.Equals(cultureCode, StringComparison.OrdinalIgnoreCase));
                var updatedPath = updatedCulturePaths.First(newPath => newPath.CultureCode.Equals(cultureCode, StringComparison.OrdinalIgnoreCase)).UrlPath;
                var parameter = new PageUrlPathUpdateParameters
                {
                    OriginalUrlPath = originalPath.UrlPath,
                    OriginalSiteId = originalSiteId,
                    NewUrlPath = updatedPath,
                    NewSiteId = newSiteId,
                    CultureCode = cultureCode
                };

                var where = PageUrlPathsUpdateHelper.GetUpdateWhereCondition(originalPath.UrlPath, cultureCode, originalSiteId);
                var ids = PageUrlPathContinuousIntegrationHelper.StartBulkUpdate(where);
                try
                {
                    ConnectionHelper.ExecuteQuery(
                        PageUrlPathsUpdateHelper.GetUpdateQueryName(),
                        PageUrlPathsUpdateHelper.GetUpdateQueryParameters(parameter, true, storeFormerUrls)
                    );
                }
                finally
                {
                    PageUrlPathContinuousIntegrationHelper.FinishBulkUpdate(ids);
                    PageFormerUrlPathContinuousIntegrationHelper.StorePaths(originalPath.UrlPath, lastFormerUrlPathId, cultureCode, originalSiteId);
                }
            }
        }


        private List<CulturePageUrlPath> GetCulturePathsToUpdate(IEnumerable<string> cultures)
        {
            return PageUrlPathInfo.Provider.Get()
                .Columns("PageUrlPathCulture", "PageUrlPathUrlPath")
                .WhereEquals("PageUrlPathNodeID", page.NodeID)
                .WhereIn("PageUrlPathCulture", cultures.ToArray())
                .Select(path => new CulturePageUrlPath { CultureCode = path.PageUrlPathCulture, UrlPath = path.PageUrlPathUrlPath })
                .ToList();
        }
    }
}
