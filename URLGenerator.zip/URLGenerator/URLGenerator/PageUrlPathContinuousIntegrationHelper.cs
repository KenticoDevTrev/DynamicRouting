﻿using System.Collections.Generic;

using CMS.ContinuousIntegration.Internal;
using CMS.DataEngine;
using CMS.DocumentEngine;

namespace URLGenerator.CMS.DocumentEngine
{
    /// <summary>
    /// Provides methods to simplify code for integration of page URL paths with continuous integration
    /// </summary>
    internal static class PageUrlPathContinuousIntegrationHelper
    {
        /// <summary>
        /// Starts the bulk update action.
        /// </summary>
        /// <param name="bulkWhere">Where condition which defines the scope of the bulk action. Where condition identifies the influenced objects before the bulk action occurs.</param>
        public static ICollection<int> StartBulkUpdate(IWhereCondition bulkWhere)
        {
            // Delete old versions of objects before the action
            return RepositoryBulkOperations.DeleteObjects(PageUrlPathInfo.TYPEINFO, bulkWhere);
        }


        /// <summary>
        /// Finishes the bulk update of page URL paths.
        /// </summary>
        /// <param name="updatedIds">Updated page URL path IDs returned from the StartBulkUpdate method</param>
        public static void FinishBulkUpdate(ICollection<int> updatedIds)
        {
            // Store new versions of objects after bulk action
            if (updatedIds == null)
            {
                return;
            }

            var where = new WhereCondition().WhereIn(PageUrlPathInfo.TYPEINFO.IDColumn, updatedIds);
            RepositoryBulkOperations.StoreObjects(PageUrlPathInfo.TYPEINFO, where);
        }


        /// <summary>
        /// Handles bulk insert of page URL paths.
        /// </summary>
        /// <param name="bulkWhere">Where condition which defines the scope of the bulk action. Where condition identifies the influenced objects before the bulk action occurs.</param>
        public static void BulkInsert(IWhereCondition bulkWhere)
        {
            RepositoryBulkOperations.StoreObjects(PageUrlPathInfo.TYPEINFO, bulkWhere);
        }
    }
}
