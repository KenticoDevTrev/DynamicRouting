﻿namespace URLGenerator.CMS.DocumentEngine.Routing
{
    /// <summary>
    /// Encapsulates page URL path for a culture version of a page.
    /// </summary>
    internal sealed class CulturePageUrlPath
    {
        /// <summary>
        /// Culture code.
        /// </summary>
        public string CultureCode { get; set; }


        /// <summary>
        /// Page URL path.
        /// </summary>
        public string UrlPath { get; set; }
    }
}
