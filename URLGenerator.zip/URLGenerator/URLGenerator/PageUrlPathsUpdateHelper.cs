﻿using System;

using CMS.DataEngine;
using CMS.DocumentEngine;

namespace URLGenerator.CMS.DocumentEngine.Routing
{
    /// <summary>
    /// Helper class encapsulating common methods for the update action and move action.
    /// </summary>
    internal static class PageUrlPathsUpdateHelper
    {
        /// <summary>
        /// Returns <see cref="WhereCondition"/> covering <see cref="PageUrlPathInfo"/> items by given parameters
        /// </summary>
        /// <param name="urlPath">URL path.</param>
        /// <param name="cultureCode">Culture code.</param>
        /// <param name="siteId">Site ID.</param>
        public static WhereCondition GetUpdateWhereCondition(string urlPath, string cultureCode, int siteId)
        {
            return new WhereCondition()
                .Where(new WhereCondition()
                    .WhereEquals("PageUrlPathUrlPath", urlPath)
                    .Or()
                    .WhereStartsWith("PageUrlPathUrlPath", urlPath + "/"))
                .WhereEquals("PageUrlPathSiteID", siteId)
                .WhereEquals("PageUrlPathCulture", cultureCode);
        }


        /// <summary>
        /// Returns name of the update query
        /// </summary>
        public static string GetUpdateQueryName()
        {
            return $"{PageUrlPathInfo.TYPEINFO.ObjectClassName}.UpdateUrlPaths";
        }

        /// <summary>
        /// Provides SQL parameters for update.
        /// </summary>
        /// <param name="updateParameters">Parameters in object representation.</param>
        /// <param name="resolveConficts">Indicates if collisions should be automatically resoled.</param>
        /// <param name="storeFormerUrls">Indicates if former URLs should be preserved.</param>
        public static QueryDataParameters GetUpdateQueryParameters(PageUrlPathUpdateParameters updateParameters, bool resolveConficts, bool storeFormerUrls)
        {
            return new QueryDataParameters()
            {
                new DataParameter("@OriginalUrlPath", updateParameters.OriginalUrlPath),
                new DataParameter("@NewUrlPath", updateParameters.NewUrlPath),
                new DataParameter("@CultureCode", updateParameters.CultureCode),
                new DataParameter("@OriginalSiteID", updateParameters.OriginalSiteId),
                new DataParameter("@NewSiteID", updateParameters.NewSiteId),
                new DataParameter("@LastModified", DateTime.Now),
                new DataParameter("@ResolveConfilcts", resolveConficts),
                new DataParameter("@StoreFormerUrls", storeFormerUrls),
            };
        }
    }
}
