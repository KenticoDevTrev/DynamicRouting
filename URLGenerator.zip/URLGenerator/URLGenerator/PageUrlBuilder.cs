﻿using System;
using System.Collections.Generic;
using System.Linq;

using CMS.DataEngine;
using CMS.DocumentEngine;
using CMS.DocumentEngine.Internal;
using CMS.DocumentEngine.Routing;
using CMS.DocumentEngine.Routing.Internal;
using CMS.Helpers;
using CMS.SiteProvider;

namespace URLGenerator.CMS.DocumentEngine.Routing
{
    /// <summary>
    /// Builds routing paths for given page for all cultures assigned to a page site.
    /// </summary>
    internal sealed class PageUrlPathBuilder : IPageUrlPathBuilder
    {
        private readonly TreeNode page;
        private readonly IEnumerable<CulturePageUrlSlug> slugs;


        /// <summary>
        /// Creates instance of <see cref="PageUrlPathBuilder"/>.
        /// </summary>
        /// <param name="page">Page to build routing paths for.</param>
        /// <param name="slugs">Existing slugs to be used for paths.</param>
        public PageUrlPathBuilder(TreeNode page, IEnumerable<CulturePageUrlSlug> slugs)
        {
            this.page = page ?? throw new ArgumentNullException(nameof(page), "The page instance needs to be provided.");
            this.slugs = slugs;
        }


        /// <summary>
        /// Builds routing paths for given page for all cultures assigned to page site.
        /// </summary>
        /// <returns>Returns routing paths based on settings configuration for all site cultures.</returns>
        public IEnumerable<CulturePageUrlPath> Build()
        {
            if (!page.HasUrl())
            {
                throw new NotSupportedException("This page type doesn't support routing.");
            }

            if (page.IsRoot())
            {
                return GetRootUrlPaths();
            }

            var parentPaths = GetParentPageUrlPaths();
            var prefixes = parentPaths.Any() ? parentPaths : GetRootUrlPaths();

            if (slugs != null && slugs.Any())
            {
                return CombineSlugsWithPrefixes(prefixes, slugs, page.NodeSiteID);
            }

            var normalizedUrlSlug = new PageUrlPathSlugNormalizer(page.DocumentName, page.NodeSiteName).Normalize();

            return CombineSlugWithPrefixes(prefixes, normalizedUrlSlug);
        }


        private IEnumerable<CulturePageUrlPath> GetParentPageUrlPaths()
        {
            var classIdsWithUrlQuery = DataClassInfoProvider.GetClasses()
                .Column("ClassID")
                .WhereEquals("ClassHasUrl", true);

            var parentNodeId = DocumentNodeDataInfo.Provider.Get()
                .Columns("NodeID")
                .OnSite(page.NodeSiteID)
                .WhereIn("NodeAliasPath", TreePathUtils.GetNodeAliasPathsOnPath(page.NodeAliasPath, false, false))
                .WhereIn("NodeClassID", classIdsWithUrlQuery)
                .OrderByDescending("NodeLevel")
                .TopN(1)
                .GetScalarResult(0);

            if (parentNodeId == 0)
            {
                return Enumerable.Empty<CulturePageUrlPath>();
            }

            return PageUrlPathInfo.Provider.Get()
                    .Columns("PageUrlPathUrlPath", "PageUrlPathCulture")
                    .WhereEquals("PageUrlPathNodeID", parentNodeId)
                    .Select(path => new CulturePageUrlPath { CultureCode = path.PageUrlPathCulture, UrlPath = path.PageUrlPathUrlPath });
        }


        private IEnumerable<CulturePageUrlPath> GetRootUrlPaths()
        {
            var useLanguagePrefixes = PageRoutingHelper.GetUrlCultureFormat(page.NodeSiteID) == PageRoutingUrlCultureFormatEnum.LanguagePrefix;
            var hideLanguagePrefixForDefaultCulture = PageRoutingHelper.HideLanguagePrefixForDefaultCultureUrl(page.NodeSiteID);
            var defaultCultureCode = CultureHelper.GetDefaultCultureCode(page.NodeSiteName);

            return CultureSiteInfoProvider.GetSiteCultures(page.NodeSiteName)
                .Select(culture =>
                {
                    var hideLanguagePrefixForCulture = !useLanguagePrefixes ||
                        (hideLanguagePrefixForDefaultCulture && string.Equals(culture.CultureCode, defaultCultureCode, StringComparison.OrdinalIgnoreCase));

                    var urlPath = hideLanguagePrefixForCulture ? string.Empty : culture.CultureCode;
                    return new CulturePageUrlPath { CultureCode = culture.CultureCode, UrlPath = urlPath };
                });
        }


        private IEnumerable<CulturePageUrlPath> CombineSlugWithPrefixes(IEnumerable<CulturePageUrlPath> pathPrefixes, string urlSlug)
        {
            return pathPrefixes.Select(pathPrefix =>
            {
                var urlPath = string.IsNullOrEmpty(pathPrefix.UrlPath) ? urlSlug : $"{pathPrefix.UrlPath}/{urlSlug}";
                return new CulturePageUrlPath { CultureCode = pathPrefix.CultureCode, UrlPath = urlPath };
            });
        }


        private IEnumerable<CulturePageUrlPath> CombineSlugsWithPrefixes(IEnumerable<CulturePageUrlPath> pathPrefixes, IEnumerable<CulturePageUrlSlug> urlSlugs, SiteInfoIdentifier site)
        {
            var defaultSlug = GetDefaultSlug(urlSlugs, site);

            foreach (var pathPrefix in pathPrefixes)
            {
                var urlSlug = urlSlugs.FirstOrDefault(slug => string.Equals(pathPrefix.CultureCode, slug.CultureCode, StringComparison.OrdinalIgnoreCase))?.Slug ?? defaultSlug.Slug;
                var urlPath = string.IsNullOrEmpty(pathPrefix.UrlPath) ? urlSlug : $"{pathPrefix.UrlPath}/{urlSlug}";
                yield return new CulturePageUrlPath { CultureCode = pathPrefix.CultureCode, UrlPath = urlPath };
            }
        }


        private static CulturePageUrlSlug GetDefaultSlug(IEnumerable<CulturePageUrlSlug> slugs, SiteInfoIdentifier site)
        {
            var defaultCultureCode = CultureHelper.GetDefaultCultureCode(site.ObjectCodeName);

            return slugs
                .OrderBy(path => path.CultureCode)
                .FirstOrDefault(path => string.Equals(path.CultureCode, defaultCultureCode, StringComparison.OrdinalIgnoreCase)) ?? slugs.First();
        }
    }
}
