﻿namespace URLGenerator.CMS.DocumentEngine.Routing
{
    /// <summary>
    /// Object representation of SQL the update procedure query parameters.
    /// </summary>
    public class PageUrlPathUpdateParameters
    {
        /// <summary>
        /// Original PageUrlPath.
        /// </summary>
        public string OriginalUrlPath { get; set; }


        /// <summary>
        /// New pageUrlPath.
        /// </summary>
        public string NewUrlPath { get; set; }


        /// <summary>
        /// Original Site ID.
        /// </summary>
        public int OriginalSiteId { get; set; }


        /// <summary>
        /// New site ID.
        /// </summary>
        public int NewSiteId { get; set; }


        /// <summary>
        /// Culture code.
        /// </summary>
        public string CultureCode { get; set; }
    }
}
