﻿using CMS.ContinuousIntegration.Internal;
using CMS.DataEngine;
using CMS.DocumentEngine;

namespace URLGenerator.CMS.DocumentEngine
{
    /// <summary>
    /// Provides helper methods for continuous integration bulk actions of <see cref="PageFormerUrlPathInfo"/>.
    /// </summary>
    public static class PageFormerUrlPathContinuousIntegrationHelper
    {
        /// <summary>
        /// Stores former URL paths on given <paramref name="urlPath"/>.
        /// </summary>
        /// <param name="urlPath">URL path of items to store.</param>
        /// <param name="startId">Former URL path ID limiting scope of <paramref name="urlPath"/>.</param>
        /// <param name="cultureCode">Culture code of items to store.</param>
        /// <param name="siteId">Site ID of items to store.</param>
        public static void StorePaths(string urlPath, int startId, string cultureCode, int siteId)
        {
            var where = new WhereCondition()
                    .Where(new WhereCondition()
                        .WhereEquals("PageFormerUrlPathUrlPath", urlPath)
                        .Or()
                        .WhereStartsWith("PageFormerUrlPathUrlPath", urlPath + "/"))
                    .WhereEquals("PageFormerUrlPathSiteID", siteId)
                    .WhereEquals("PageFormerUrlPathCulture", cultureCode)
                    .WhereGreaterThan("PageFormerUrlPathID", startId);
            RepositoryBulkOperations.StoreObjects(PageFormerUrlPathInfo.TYPEINFO, where);
        }


        /// <summary>
        /// Gets the ID of the last former URL path in the database.
        /// </summary>
        public static int GetLastFormerUrlPathId()
        {
            return PageFormerUrlPathInfo.Provider.Get()
                .Column(new AggregatedColumn(AggregationType.Max, "PageFormerUrlPathID").As("PageFormerUrlPathID"))
                .GetScalarResult<int>();
        }
    }
}
