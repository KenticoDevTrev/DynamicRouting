﻿using System.Collections.Generic;

namespace URLGenerator.CMS.DocumentEngine.Routing
{
    /// <summary>
    /// Interface for routing path builder.
    /// </summary>
    internal interface IPageUrlPathBuilder
    {
        /// <summary>
        /// Builds routing paths for given page for all cultures assigned to page site.
        /// </summary>
        /// <returns>Returns routing paths based on settings configuration for all site cultures.</returns>
        IEnumerable<CulturePageUrlPath> Build();
    }
}
