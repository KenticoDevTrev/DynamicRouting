﻿using System;

using CMS.DataEngine;
using CMS.DocumentEngine.Routing.Internal;
using CMS.Helpers;

namespace URLGenerator.CMS.DocumentEngine.Routing
{
    /// <summary>
    /// Normalizes the page URL slug.
    /// </summary>
    public class PageUrlPathSlugNormalizer
    {
        private readonly string pageUrlSlug;
        private readonly SiteInfoIdentifier site;


        /// <summary>
        /// Creates instance of <see cref="PageUrlPathSlugNormalizer"/>.
        /// </summary>
        /// <param name="pageUrlSlug">Page URL slug.</param>
        /// <param name="site">Site.</param>
        public PageUrlPathSlugNormalizer(string pageUrlSlug, SiteInfoIdentifier site)
        {
            if (string.IsNullOrWhiteSpace(pageUrlSlug))
            {
                throw new ArgumentException("The page URL slug cannot be an empty string.", nameof(pageUrlSlug));
            }

            this.pageUrlSlug = pageUrlSlug;
            this.site = site;
        }


        /// <summary>
        /// Normalizes the page URL slug.
        /// </summary>
        /// <returns>Returns normalized page URL slug with correct length, without invalid URL characters.</returns>
        public string Normalize()
        {
            var normalizedUrlSlug = pageUrlSlug.Trim();
            if (normalizedUrlSlug.Length > PageUrlPath.SLUG_LENGTH)
            {
                normalizedUrlSlug = normalizedUrlSlug.Substring(0, PageUrlPath.SLUG_LENGTH);
            }

            return URLHelper.GetSafeUrlPart(normalizedUrlSlug, site);
        }
    }
}
