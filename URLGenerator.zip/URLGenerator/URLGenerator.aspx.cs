﻿using CMS.DataEngine;
using CMS.DocumentEngine;
using CMS.SiteProvider;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using URLGenerator.CMS.DocumentEngine.Routing;
using TreeNode = CMS.DocumentEngine.TreeNode;

namespace CMSApp.CMSPages.Custom
{
    public partial class URLGenerator : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnFix_Click(object sender, EventArgs e)
        {
            
            Dictionary<int, List<string>> siteToCultures = new Dictionary<int, List<string>>();
            foreach (var site in SiteInfo.Provider.Get().TypedResult)
            {
                siteToCultures.Add(site.SiteID, CultureSiteInfoProvider.GetSiteCultures(site.SiteName).Select(x => x.CultureCode).ToList());
            }


            // Get all pages, the GetDocuments sometimes misses new newly converted nodes due to lack of history / workflow / publish status
            var allPages = ConnectionHelper.ExecuteQuery($"select * from View_CMS_Tree_Joined order by NodeSiteID, NodeOrder, NodeLevel", null, QueryTypeEnum.SQLQuery).Tables[0].Rows.Cast<DataRow>().Select(x => TreeNode.New(x)).ToArray();

            for (int i = 0; i < allPages.Length; i++)
            {
                var page = allPages[i];
                if(page.HasUrl()) { 
                    PageUrlPathCulturePathsUpdater updater = new PageUrlPathCulturePathsUpdater(page);
                    updater.Update(siteToCultures[page.NodeSiteID], page.NodeSiteID, page.NodeSiteID);
                }
            }


        }
    }
}